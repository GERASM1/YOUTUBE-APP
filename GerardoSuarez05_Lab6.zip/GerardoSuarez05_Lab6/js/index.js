var previousToken = "";
var nextToken = "";

function fetchVideos(pageToken) {
    $("#videos").html(""); 
    let apiKey = "AIzaSyDX6FUxmCGSHvNPpreMhotwIInV_RDZtRA";
    let videoName = $("#searchVideo").val();
    let url = "https://www.googleapis.com/youtube/v3/search";

    $.ajax({
        url: url,
        data: {
            part: "snippet",
            q: videoName,
            key: apiKey,
            maxResults: 10,
            pageToken: pageToken,
        },
        method: "GET",
        dataType: "json",
        success: function(responseJSON) {
            responseJSON.items.forEach((el) => {
                let youtubeUrl = "https://www.youtube.com/watch?v=" + el.id.videoId;
                $("#videos").append(`<li> 
                                        <div>
                                            <h3><a href=${youtubeUrl} target="_blank">${el.snippet.title}</a></h3>
                                            <a href=${youtubeUrl} target="_blank"><img src="${el.snippet.thumbnails.medium.url}" /></a>
                                        </div>
                                    </li>
                                    <hr>`
                                );
            });
            let nextPageButton = $("<button type='submit' class='nextButton'>Next Page</button>");
            let previousPageButton = $("<button type='submit' class='previousButton'>Previous Page</button>");

            if(pageToken != "") {
                previousToken = responseJSON.prevPageToken;
                $("#videos").append(previousPageButton, nextPageButton);
            } else {
                previousToken = "";
                $("#videos").append(nextPageButton);
            }
            nextToken = responseJSON.nextPageToken;
        },
        error: function(err) {
            console.log(err);
        }
    });
}

$("#videoForm").on("submit", function(e) {
    e.preventDefault();

    if ($("#searchVideo").val() == "") {
        $("#videos").html("");
        console.log("ERROR: no search videoName");
    } else {
        fetchVideos("");
    }
});

$("ul").on("click", ".nextButton", (e) => {
    e.preventDefault();
    fetchVideos(nextToken);
    return;
});

$("ul").on("click", ".previousButton", (e) => {
    e.preventDefault();
    fetchVideos(previousToken);
    return;
});